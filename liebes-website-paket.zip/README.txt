LIEBES-WEBSITE – KOSTENLOS VERÖFFENTLICHEN

1. Gehe auf https://github.com und erstelle kostenlos ein Konto oder melde dich an.
2. Klicke auf „New repository“.
3. Repository name: liebesgruss (oder ein anderer Name).
4. Wähle „Public“ und klicke „Create repository“.
5. Klicke „Add file“ > „Upload files“.
6. Lade die Datei index.html aus diesem Ordner hoch und klicke „Commit changes“.
7. Öffne im Repository „Settings“ > „Pages“.
8. Unter „Build and deployment“ bei „Source“: „Deploy from a branch“ wählen.
9. Bei Branch „main“ und Ordner „/(root)“ auswählen, dann „Save“.
10. Warte ein paar Minuten. Unter Settings > Pages erscheint „Visit site“.
    Deine Adresse sieht ungefähr so aus: https://DEIN-NUTZERNAME.github.io/liebesgruss/

WICHTIG:
- Die Website ist öffentlich erreichbar. Lade keine privaten Fotos oder persönlichen Daten hoch.
- Der QR-Code kann erst mit der endgültigen Website-Adresse erstellt werden.
- Sobald deine Seite online ist, schicke mir einfach den Link. Ich erstelle dir daraus
  einen druckfertigen QR-Code.
